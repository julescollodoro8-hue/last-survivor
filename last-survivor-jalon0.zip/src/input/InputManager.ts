import type { System } from "../core/System";

const JOY_RADIUS = 56; // px

/**
 * Entrées : joystick flottant (moitié gauche de l'écran), caméra au doigt (moitié droite),
 * clavier ZQSD/WASD + flèches + Maj pour tester sur ordinateur.
 */
export class InputManager implements System {
  readonly name = "input";
  /** Mouvement demandé : x = droite, y = avant, norme dans [0, 1]. */
  moveX = 0;
  moveY = 0;

  private touchX = 0;
  private touchY = 0;
  private lookDX = 0;
  private lookDY = 0;
  private readonly keys = new Set<string>();
  private movePointer: number | null = null;
  private lookPointer: number | null = null;
  private originX = 0;
  private originY = 0;
  private lastX = 0;
  private lastY = 0;

  constructor(
    private readonly zoneMove: HTMLElement,
    private readonly zoneLook: HTMLElement,
    private readonly joy: HTMLElement,
    private readonly knob: HTMLElement,
  ) {
    this.bindMove();
    this.bindLook();
    window.addEventListener("keydown", (e) => this.keys.add(e.code));
    window.addEventListener("keyup", (e) => this.keys.delete(e.code));
    window.addEventListener("blur", () => this.keys.clear());
  }

  private bindMove(): void {
    const z = this.zoneMove;
    z.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      if (this.movePointer !== null) return;
      this.movePointer = e.pointerId;
      z.setPointerCapture(e.pointerId);
      this.originX = e.clientX;
      this.originY = e.clientY;
      this.joy.style.left = `${e.clientX}px`;
      this.joy.style.top = `${e.clientY}px`;
      this.knob.style.transform = "translate(0px, 0px)";
      this.joy.classList.add("on");
    });
    z.addEventListener("pointermove", (e) => {
      if (e.pointerId !== this.movePointer) return;
      let dx = e.clientX - this.originX;
      let dy = e.clientY - this.originY;
      const len = Math.hypot(dx, dy);
      if (len > JOY_RADIUS) {
        dx = (dx / len) * JOY_RADIUS;
        dy = (dy / len) * JOY_RADIUS;
      }
      this.touchX = dx / JOY_RADIUS;
      this.touchY = -dy / JOY_RADIUS;
      this.knob.style.transform = `translate(${dx}px, ${dy}px)`;
    });
    const end = (e: PointerEvent): void => {
      if (e.pointerId !== this.movePointer) return;
      this.movePointer = null;
      this.touchX = 0;
      this.touchY = 0;
      this.joy.classList.remove("on");
    };
    z.addEventListener("pointerup", end);
    z.addEventListener("pointercancel", end);
  }

  private bindLook(): void {
    const z = this.zoneLook;
    z.addEventListener("pointerdown", (e) => {
      e.preventDefault();
      if (this.lookPointer !== null) return;
      this.lookPointer = e.pointerId;
      z.setPointerCapture(e.pointerId);
      this.lastX = e.clientX;
      this.lastY = e.clientY;
    });
    z.addEventListener("pointermove", (e) => {
      if (e.pointerId !== this.lookPointer) return;
      this.lookDX += e.clientX - this.lastX;
      this.lookDY += e.clientY - this.lastY;
      this.lastX = e.clientX;
      this.lastY = e.clientY;
    });
    const end = (e: PointerEvent): void => {
      if (e.pointerId === this.lookPointer) this.lookPointer = null;
    };
    z.addEventListener("pointerup", end);
    z.addEventListener("pointercancel", end);
  }

  /** Renvoie et remet à zéro le déplacement de caméra accumulé (en pixels). */
  consumeLook(): { dx: number; dy: number } {
    const out = { dx: this.lookDX, dy: this.lookDY };
    this.lookDX = 0;
    this.lookDY = 0;
    return out;
  }

  update(): void {
    const k = this.keys;
    const kx = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0);
    const ky = (k.has("KeyW") || k.has("ArrowUp") ? 1 : 0) - (k.has("KeyS") || k.has("ArrowDown") ? 1 : 0);
    if (kx !== 0 || ky !== 0) {
      const len = Math.hypot(kx, ky);
      const mag = k.has("ShiftLeft") || k.has("ShiftRight") ? 1 : 0.6;
      this.moveX = (kx / len) * mag;
      this.moveY = (ky / len) * mag;
    } else {
      this.moveX = this.touchX;
      this.moveY = this.touchY;
    }
  }
}

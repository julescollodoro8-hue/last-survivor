/** Constantes globales du monde, du joueur et de la caméra. */
export const WORLD = { size: 600, seaLevel: 0, seaFloor: -9 } as const;

export const PLAYER = {
  walkSpeed: 4.2,
  runSpeed: 7.5,
  turnRate: 12,
  maxSlope: 1.1, // pente max franchissable (dh / distance)
  minGround: -1.0, // profondeur max où l'on peut marcher (gué)
} as const;

export const CAMERA = {
  distance: 5.5,
  height: 1.55,
  minPitch: -0.15,
  maxPitch: 1.25,
  lookSensX: 0.0055,
  lookSensY: 0.0045,
} as const;

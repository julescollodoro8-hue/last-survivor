export type QualityId = "low" | "normal" | "high";

export interface QualitySettings {
  id: QualityId;
  label: string;
  pixelRatio: number; // densité de rendu maximale (plafonnée au devicePixelRatio)
  terrainRes: number; // sommets par côté du terrain
  shadowMapSize: number; // 0 = pas d'ombres
  shadowFilter: "none" | "poisson" | "pcf";
  fogDensity: number;
  fpsCap: number;
}

export const QUALITIES: Record<QualityId, QualitySettings> = {
  low: { id: "low", label: "Léger", pixelRatio: 1, terrainRes: 96, shadowMapSize: 0, shadowFilter: "none", fogDensity: 0.01, fpsCap: 30 },
  normal: { id: "normal", label: "Normal", pixelRatio: 1.5, terrainRes: 160, shadowMapSize: 1024, shadowFilter: "poisson", fogDensity: 0.0065, fpsCap: 60 },
  high: { id: "high", label: "Élevé", pixelRatio: 2, terrainRes: 224, shadowMapSize: 2048, shadowFilter: "pcf", fogDensity: 0.0045, fpsCap: 60 },
};

const KEY = "lastsurvivor.quality";

function isQuality(v: string | null): v is QualityId {
  return v === "low" || v === "normal" || v === "high";
}

export function loadQuality(): QualityId {
  const fromUrl = new URLSearchParams(location.search).get("q");
  if (isQuality(fromUrl)) return fromUrl;
  try {
    const saved = localStorage.getItem(KEY);
    if (isQuality(saved)) return saved;
  } catch {
    /* stockage indisponible : on garde la valeur par défaut */
  }
  return "normal";
}

export function saveQuality(id: QualityId): void {
  try {
    localStorage.setItem(KEY, id);
  } catch {
    /* ignoré */
  }
}

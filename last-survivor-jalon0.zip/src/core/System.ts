import type { QualityId } from "./quality";

/** Tout module de jeu (joueur, IA, zone, loot…) s'enregistre comme System et reçoit update(dt) chaque image. */
export interface System {
  readonly name: string;
  update(dt: number): void;
  dispose?(): void;
}

/** Petit bus d'événements typé pour découpler les modules. */
export class EventBus<E> {
  private map: { [K in keyof E]?: Array<(payload: E[K]) => void> } = {};

  on<K extends keyof E>(key: K, fn: (payload: E[K]) => void): () => void {
    (this.map[key] ??= []).push(fn);
    return () => this.off(key, fn);
  }

  off<K extends keyof E>(key: K, fn: (payload: E[K]) => void): void {
    const list = this.map[key];
    if (!list) return;
    const i = list.indexOf(fn);
    if (i >= 0) list.splice(i, 1);
  }

  emit<K extends keyof E>(key: K, payload: E[K]): void {
    this.map[key]?.slice().forEach((fn) => fn(payload));
  }
}

export interface GameEvents {
  qualityChanged: QualityId;
}

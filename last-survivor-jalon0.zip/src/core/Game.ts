import type { AbstractEngine } from "@babylonjs/core";
import { Diagnostics } from "../debug/Diagnostics";
import { ErrorLog } from "../debug/ErrorLog";
import { InputManager } from "../input/InputManager";
import { Player } from "../player/Player";
import { ThirdPersonCamera } from "../player/ThirdPersonCamera";
import { createEngine } from "../render/createEngine";
import { Renderer } from "../render/Renderer";
import { el } from "../ui/dom";
import { Hud } from "../ui/Hud";
import { Terrain } from "../world/Terrain";
import { QUALITIES, loadQuality, saveQuality, type QualityId, type QualitySettings } from "./quality";
import { EventBus, type GameEvents, type System } from "./System";

/**
 * Chef d'orchestre. Les futurs modules (ai, combat, inventory, loot, zone, vehicles, net)
 * s'ajoutent en créant un System et en l'enregistrant dans `systems`.
 */
export class Game {
  readonly events = new EventBus<GameEvents>();
  readonly renderer: Renderer;
  readonly terrain: Terrain;
  readonly input: InputManager;
  readonly player: Player;
  readonly cameraCtl: ThirdPersonCamera;
  readonly diagnostics: Diagnostics;
  readonly hud: Hud;
  quality: QualitySettings;

  private readonly systems: System[];
  private last = 0;

  static async create(canvas: HTMLCanvasElement): Promise<Game> {
    const { engine, backend } = await createEngine(canvas);
    return new Game(engine, backend);
  }

  private constructor(engine: AbstractEngine, backend: string) {
    this.quality = QUALITIES[loadQuality()];
    this.renderer = new Renderer(engine, backend);
    this.terrain = new Terrain(this.renderer.scene);
    this.terrain.rebuild(this.quality.terrainRes);

    this.input = new InputManager(el("zone-move"), el("zone-look"), el("joy"), el("joy-knob"));
    this.cameraCtl = new ThirdPersonCamera(this.renderer.camera, this.input, this.terrain);
    this.player = new Player(this.renderer.scene, this.terrain, this.input, this.cameraCtl, this.renderer);
    this.cameraCtl.focus = this.player.position;
    this.renderer.focus = this.player.position;

    if (this.terrain.mesh) this.renderer.setReceivers([this.terrain.mesh]);
    this.renderer.applyQuality(this.quality);

    this.diagnostics = new Diagnostics(this.renderer, this.terrain, this.player, () => this.quality);
    this.hud = new Hud(this);

    // Ordre d'exécution : entrées → joueur → caméra → rendu → diagnostic
    this.systems = [this.input, this.player, this.cameraCtl, this.renderer, this.diagnostics];
  }

  setQuality(id: QualityId): void {
    this.quality = QUALITIES[id];
    saveQuality(id);
    this.terrain.rebuild(this.quality.terrainRes);
    if (this.terrain.mesh) this.renderer.setReceivers([this.terrain.mesh]);
    this.renderer.applyQuality(this.quality);
    this.events.emit("qualityChanged", id);
  }

  /** Appelle `fn` quand la scène (matériaux compris) est prête à s'afficher. */
  onReady(fn: () => void): void {
    this.renderer.scene.executeWhenReady(fn);
  }

  start(): void {
    const engine = this.renderer.engine;
    this.last = performance.now();
    engine.runRenderLoop(() => {
      const now = performance.now();
      const minDelta = 1000 / this.quality.fpsCap - 1.5;
      if (now - this.last < minDelta) return;
      const dt = Math.min((now - this.last) / 1000, 0.05);
      this.last = now;
      for (const s of this.systems) {
        try {
          s.update(dt);
        } catch (e) {
          ErrorLog.add("error", `${s.name}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }
      this.renderer.scene.render();
    });
    window.addEventListener("resize", () => engine.resize());
    window.addEventListener("orientationchange", () => window.setTimeout(() => engine.resize(), 250));
  }
}

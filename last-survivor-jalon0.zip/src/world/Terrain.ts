import { Color3, Mesh, MeshBuilder, Scene, StandardMaterial, VertexData } from "@babylonjs/core";
import { WORLD } from "../core/config";
import { clamp, fbm, lerp, smoothstep, valueNoise } from "./noise";

/** Hauteur analytique du terrain : sert à la fois au rendu et aux collisions (exacte, sans raycast). */
export function terrainHeight(x: number, z: number): number {
  const half = WORLD.size / 2;
  const coast = (fbm(x * 0.006 + 40, z * 0.006 + 40, 3, 11) - 0.5) * 0.3;
  const d = Math.hypot(x, z) / half + coast;
  const mask = 1 - smoothstep(0.5, 0.95, d);
  const relief = clamp((fbm(x * 0.0045, z * 0.0045, 5, 3) - 0.5) * 1.7 + 0.5, 0, 1);
  const detail = fbm(x * 0.03, z * 0.03, 3, 5);
  const land = (relief - 0.12) * 52 + (detail - 0.5) * 3;
  return lerp(WORLD.seaFloor, land, mask);
}

export class Terrain {
  mesh: Mesh | null = null;
  vertexCount = 0;
  resolution = 0;
  private readonly material: StandardMaterial;
  private readonly water: Mesh;

  constructor(private readonly scene: Scene) {
    this.material = new StandardMaterial("terrainMat", scene);
    this.material.specularColor = Color3.Black();
    this.material.backFaceCulling = false;

    this.water = MeshBuilder.CreateGround("water", { width: 1400, height: 1400, subdivisions: 1 }, scene);
    this.water.position.y = WORLD.seaLevel;
    this.water.isPickable = false;
    const wm = new StandardMaterial("waterMat", scene);
    wm.diffuseColor = new Color3(0.07, 0.3, 0.42);
    wm.specularColor = new Color3(0.55, 0.65, 0.7);
    wm.specularPower = 64;
    wm.alpha = 0.82;
    wm.backFaceCulling = false;
    this.water.material = wm;
  }

  height(x: number, z: number): number {
    return terrainHeight(x, z);
  }

  /** Cherche un point de départ sur la terre ferme, hors plage et hors montagne. */
  findSpawn(): { x: number; z: number } {
    for (let r = 0; r <= 160; r += 10) {
      for (let k = 0; k < 8; k++) {
        const a = (k / 8) * Math.PI * 2;
        const x = Math.cos(a) * r;
        const z = Math.sin(a) * r;
        const h = terrainHeight(x, z);
        if (h >= 3 && h <= 14) return { x, z };
      }
    }
    return { x: 0, z: 0 };
  }

  /** (Re)construit le maillage du terrain avec `res` x `res` sommets. */
  rebuild(res: number): void {
    if (res === this.resolution && this.mesh) return;
    this.resolution = res;
    this.mesh?.dispose();

    const N = res;
    const size = WORLD.size;
    const step = size / (N - 1);
    const half = size / 2;

    const heights = new Float32Array(N * N);
    const positions = new Float32Array(N * N * 3);
    for (let iz = 0; iz < N; iz++) {
      for (let ix = 0; ix < N; ix++) {
        const i = iz * N + ix;
        const x = -half + ix * step;
        const z = -half + iz * step;
        const h = terrainHeight(x, z);
        heights[i] = h;
        positions[i * 3] = x;
        positions[i * 3 + 1] = h;
        positions[i * 3 + 2] = z;
      }
    }

    const normals = new Float32Array(N * N * 3);
    const colors = new Float32Array(N * N * 4);
    for (let iz = 0; iz < N; iz++) {
      for (let ix = 0; ix < N; ix++) {
        const i = iz * N + ix;
        const xl = Math.max(ix - 1, 0);
        const xr = Math.min(ix + 1, N - 1);
        const zd = Math.max(iz - 1, 0);
        const zu = Math.min(iz + 1, N - 1);
        const dhdx = (heights[iz * N + xr] - heights[iz * N + xl]) / ((xr - xl) * step);
        const dhdz = (heights[zu * N + ix] - heights[zd * N + ix]) / ((zu - zd) * step);
        const inv = 1 / Math.hypot(dhdx, 1, dhdz);
        normals[i * 3] = -dhdx * inv;
        normals[i * 3 + 1] = inv;
        normals[i * 3 + 2] = -dhdz * inv;

        const slope = Math.hypot(dhdx, dhdz);
        this.colorAt(heights[i], slope, positions[i * 3], positions[i * 3 + 2], colors, i * 4);
      }
    }

    const indices = new Uint32Array((N - 1) * (N - 1) * 6);
    let k = 0;
    for (let iz = 0; iz < N - 1; iz++) {
      for (let ix = 0; ix < N - 1; ix++) {
        const a = iz * N + ix;
        const b = a + 1;
        const c = a + N;
        const d = c + 1;
        indices[k++] = a;
        indices[k++] = b;
        indices[k++] = c;
        indices[k++] = b;
        indices[k++] = d;
        indices[k++] = c;
      }
    }

    const mesh = new Mesh("terrain", this.scene);
    const data = new VertexData();
    data.positions = positions;
    data.normals = normals;
    data.colors = colors;
    data.indices = indices;
    data.applyToMesh(mesh);
    mesh.material = this.material;
    mesh.isPickable = false;
    mesh.freezeWorldMatrix();
    this.mesh = mesh;
    this.vertexCount = N * N;
  }

  private colorAt(h: number, slope: number, x: number, z: number, out: Float32Array, o: number): void {
    const n = valueNoise(x * 0.07, z * 0.07, 7);
    let r: number;
    let g: number;
    let b: number;
    if (h < 2.5) {
      // fond marin et plage
      const t = smoothstep(0.0, 2.5, h);
      r = lerp(0.5, 0.8, t);
      g = lerp(0.46, 0.72, t);
      b = lerp(0.34, 0.52, t);
    } else {
      r = lerp(0.15, 0.34, n);
      g = lerp(0.32, 0.5, n);
      b = lerp(0.11, 0.17, n);
      const rock = smoothstep(0.55, 0.95, slope);
      r = lerp(r, 0.46, rock);
      g = lerp(g, 0.44, rock);
      b = lerp(b, 0.4, rock);
      const snow = smoothstep(36, 44, h);
      r = lerp(r, 0.93, snow);
      g = lerp(g, 0.95, snow);
      b = lerp(b, 0.98, snow);
    }
    out[o] = r;
    out[o + 1] = g;
    out[o + 2] = b;
    out[o + 3] = 1;
  }
}

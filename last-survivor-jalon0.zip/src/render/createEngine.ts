import { AbstractEngine, Engine } from "@babylonjs/core";
import { ErrorLog } from "../debug/ErrorLog";

export interface EngineHandle {
  engine: AbstractEngine;
  backend: string;
}

const errText = (e: unknown): string => (e instanceof Error ? e.message : String(e));

/**
 * WebGL 2 par défaut (chemin éprouvé). WebGPU uniquement si l'adresse contient ?webgpu=1,
 * avec repli automatique sur WebGL 2 en cas d'échec.
 */
export async function createEngine(canvas: HTMLCanvasElement): Promise<EngineHandle> {
  let target = canvas;
  const wantGpu = new URLSearchParams(location.search).get("webgpu") === "1";

  if (wantGpu) {
    try {
      if (!("gpu" in navigator)) throw new Error("navigator.gpu indisponible");
      const { WebGPUEngine } = await import("@babylonjs/core/Engines/webgpuEngine");
      const gpu = new WebGPUEngine(canvas, { antialias: false, adaptToDeviceRatio: false });
      await gpu.initAsync();
      return { engine: gpu, backend: "WebGPU" };
    } catch (e) {
      ErrorLog.add("warn", "WebGPU indisponible, repli sur WebGL 2 : " + errText(e));
      // Un canvas ne peut pas changer de type de contexte : on en met un neuf.
      const fresh = canvas.cloneNode(false) as HTMLCanvasElement;
      canvas.replaceWith(fresh);
      target = fresh;
    }
  }

  const engine = new Engine(
    target,
    false,
    { powerPreference: "high-performance", stencil: false, preserveDrawingBuffer: false },
    false,
  );
  engine.onContextLostObservable.add(() => ErrorLog.add("error", "Contexte WebGL perdu (mémoire ou surchauffe)"));
  return { engine, backend: engine.webGLVersion >= 2 ? "WebGL 2" : "WebGL 1" };
}

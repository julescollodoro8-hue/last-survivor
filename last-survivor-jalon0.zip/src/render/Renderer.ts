import {
  AbstractEngine,
  AbstractMesh,
  Color3,
  Color4,
  DirectionalLight,
  FreeCamera,
  HemisphericLight,
  Mesh,
  MeshBuilder,
  Scene,
  ShadowGenerator,
  StandardMaterial,
  Vector3,
  VertexBuffer,
} from "@babylonjs/core";
import type { QualitySettings } from "../core/quality";
import type { System } from "../core/System";

const HORIZON = new Color3(0.72, 0.82, 0.92);
const ZENITH = new Color3(0.2, 0.42, 0.8);

/** Scène, caméra, lumières, ciel, brouillard et ombres. Applique les réglages de qualité. */
export class Renderer implements System {
  readonly name = "renderer";
  readonly scene: Scene;
  readonly camera: FreeCamera;
  readonly sun: DirectionalLight;
  /** Point autour duquel la carte d'ombres suit le joueur. */
  focus = new Vector3();

  private shadow: ShadowGenerator | null = null;
  private casters: AbstractMesh[] = [];
  private receivers: AbstractMesh[] = [];
  private readonly sky: Mesh;
  private readonly tmp = new Vector3();

  constructor(
    readonly engine: AbstractEngine,
    readonly backend: string,
  ) {
    const scene = new Scene(engine);
    scene.clearColor = new Color4(HORIZON.r, HORIZON.g, HORIZON.b, 1);
    scene.fogMode = Scene.FOGMODE_EXP2;
    scene.fogColor = HORIZON.clone();
    scene.skipPointerMovePicking = true;
    scene.detachControl(); // les entrées sont gérées par InputManager
    this.scene = scene;

    this.camera = new FreeCamera("camera", new Vector3(0, 30, -20), scene);
    this.camera.minZ = 0.3;
    this.camera.maxZ = 1000;
    this.camera.fov = 0.95;
    this.camera.inputs.clear();
    scene.activeCamera = this.camera;

    const hemi = new HemisphericLight("hemi", new Vector3(0, 1, 0), scene);
    hemi.intensity = 0.6;
    hemi.diffuse = new Color3(0.78, 0.86, 1);
    hemi.groundColor = new Color3(0.3, 0.3, 0.25);
    hemi.specular = Color3.Black();

    this.sun = new DirectionalLight("sun", new Vector3(-0.45, -0.8, -0.35).normalize(), scene);
    this.sun.intensity = 1.15;
    this.sun.diffuse = new Color3(1, 0.95, 0.85);
    this.sun.specular = new Color3(0.25, 0.25, 0.25);
    this.sun.autoUpdateExtends = false;
    this.sun.autoCalcShadowZBounds = false;
    this.sun.orthoLeft = -14;
    this.sun.orthoRight = 14;
    this.sun.orthoTop = 14;
    this.sun.orthoBottom = -14;
    this.sun.shadowMinZ = 1;
    this.sun.shadowMaxZ = 140;

    this.sky = this.createSky();
    scene.onBeforeRenderObservable.add(() => this.sky.position.copyFrom(this.camera.position));
  }

  /** Dôme de ciel : dégradé horizon → zénith porté par les couleurs de sommets. */
  private createSky(): Mesh {
    const radius = 700;
    const sky = MeshBuilder.CreateSphere("sky", { diameter: radius * 2, segments: 32, sideOrientation: Mesh.BACKSIDE }, this.scene);
    const pos = sky.getVerticesData(VertexBuffer.PositionKind);
    if (pos) {
      const colors = new Float32Array((pos.length / 3) * 4);
      for (let i = 0; i < pos.length / 3; i++) {
        const t = pos[i * 3 + 1] / radius; // -1 (nadir) → 1 (zénith)
        const k = t <= 0 ? 0 : Math.pow(t, 0.55);
        colors[i * 4] = HORIZON.r + (ZENITH.r - HORIZON.r) * k;
        colors[i * 4 + 1] = HORIZON.g + (ZENITH.g - HORIZON.g) * k;
        colors[i * 4 + 2] = HORIZON.b + (ZENITH.b - HORIZON.b) * k;
        colors[i * 4 + 3] = 1;
      }
      sky.setVerticesData(VertexBuffer.ColorKind, colors, false);
    }
    const mat = new StandardMaterial("skyMat", this.scene);
    mat.disableLighting = true;
    mat.diffuseColor = Color3.Black();
    mat.specularColor = Color3.Black();
    mat.emissiveColor = Color3.White(); // × couleurs de sommets = dégradé
    mat.backFaceCulling = false;
    mat.fogEnabled = false;
    sky.material = mat;
    sky.applyFog = false;
    sky.isPickable = false;
    return sky;
  }

  addCaster(mesh: AbstractMesh): void {
    this.casters.push(mesh);
    this.shadow?.addShadowCaster(mesh);
  }

  setReceivers(list: AbstractMesh[]): void {
    this.receivers = list;
  }

  applyQuality(q: QualitySettings): void {
    const ratio = Math.min(q.pixelRatio, window.devicePixelRatio || 1);
    this.engine.setHardwareScalingLevel(1 / ratio);
    this.engine.resize();
    this.scene.fogDensity = q.fogDensity;

    this.shadow?.dispose();
    this.shadow = null;
    if (q.shadowMapSize > 0) {
      const sg = new ShadowGenerator(q.shadowMapSize, this.sun);
      sg.bias = 0.0005;
      sg.normalBias = 0.02;
      sg.setDarkness(0.35);
      if (q.shadowFilter === "pcf") {
        sg.usePercentageCloserFiltering = true;
        sg.filteringQuality = ShadowGenerator.QUALITY_MEDIUM;
      } else {
        sg.usePoissonSampling = true;
      }
      for (const m of this.casters) sg.addShadowCaster(m);
      this.shadow = sg;
    }
    for (const r of this.receivers) r.receiveShadows = this.shadow !== null;
  }

  update(): void {
    if (!this.shadow) return;
    this.tmp.copyFrom(this.sun.direction).normalize().scaleInPlace(60);
    this.sun.position = this.focus.subtract(this.tmp);
  }

  dispose(): void {
    this.scene.dispose();
    this.engine.dispose();
  }
}

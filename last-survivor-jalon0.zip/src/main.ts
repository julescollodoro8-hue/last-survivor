import "./ui/styles.css";
import { Game } from "./core/Game";
import { ErrorLog } from "./debug/ErrorLog";

ErrorLog.install();

// Empêche le zoom par pincement de Safari pendant le jeu.
document.addEventListener("gesturestart", (e) => e.preventDefault());

function setBootMessage(text: string, isError = false): void {
  const m = document.getElementById("boot-msg");
  if (!m) return;
  m.textContent = text;
  m.className = isError ? "err" : "";
}

async function boot(): Promise<void> {
  const canvas = document.getElementById("game") as HTMLCanvasElement | null;
  if (!canvas) throw new Error("Canvas #game introuvable");
  setBootMessage("Initialisation du rendu…");
  const game = await Game.create(canvas);
  setBootMessage("Construction du monde…");
  game.onReady(() => {
    (window as unknown as { __ready?: boolean }).__ready = true;
    document.getElementById("boot")?.classList.add("hide");
  });
  game.start();
}

boot().catch((err: unknown) => {
  const text = err instanceof Error ? `${err.name} : ${err.message}` : String(err);
  ErrorLog.add("error", "Démarrage : " + text);
  setBootMessage("Erreur au démarrage : " + text, true);
});

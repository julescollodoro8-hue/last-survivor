import { Engine, SceneInstrumentation } from "@babylonjs/core";
import type { QualitySettings } from "../core/quality";
import type { System } from "../core/System";
import type { Player } from "../player/Player";
import type { Renderer } from "../render/Renderer";
import { el } from "../ui/dom";
import type { Terrain } from "../world/Terrain";
import { ErrorLog } from "./ErrorLog";

/** Panneau de diagnostic : FPS, GPU, charge de la scène, erreurs. Le rapport est copiable. */
export class Diagnostics implements System {
  readonly name = "diagnostics";
  private acc = 0;
  private readonly inst: SceneInstrumentation;
  private readonly fps = el("fps");
  private readonly text = el("diag-text");
  private readonly panel = el("panel-diag");
  private readonly btn = el("btn-diag");

  constructor(
    private readonly renderer: Renderer,
    private readonly terrain: Terrain,
    private readonly player: Player,
    private readonly getQuality: () => QualitySettings,
  ) {
    this.inst = new SceneInstrumentation(renderer.scene);
    el("btn-copy").addEventListener("click", () => void this.copy());
  }

  update(dt: number): void {
    this.acc += dt;
    if (this.acc < 0.5) return;
    this.acc = 0;
    this.fps.textContent = `${Math.round(this.renderer.engine.getFps())} FPS`;
    this.btn.classList.toggle("alert", ErrorLog.errorCount > 0);
    if (!this.panel.hidden) this.text.textContent = this.report();
  }

  report(): string {
    const e = this.renderer.engine;
    const s = this.renderer.scene;
    const q = this.getQuality();
    const p = this.player.position;

    let gpu = "n/a";
    try {
      const info = (e as unknown as { getGlInfo?: () => { renderer: string } }).getGlInfo?.();
      if (info) gpu = info.renderer;
    } catch {
      /* ignoré */
    }
    const mem = (performance as unknown as { memory?: { usedJSHeapSize: number } }).memory;
    const heap = mem ? `${Math.round(mem.usedJSHeapSize / 1048576)} Mo` : "n/a (Safari)";

    const lines = [
      `FPS ${Math.round(e.getFps())}  |  image ${e.getDeltaTime().toFixed(1)} ms`,
      `Rendu : ${this.renderer.backend}  |  Babylon ${Engine.Version}`,
      `GPU : ${gpu}`,
      `Qualité : ${q.label}  |  plafond ${q.fpsCap} FPS`,
      `Résolution : ${e.getRenderWidth()}x${e.getRenderHeight()}  |  échelle ${e.getHardwareScalingLevel().toFixed(2)}`,
      `Terrain : ${this.terrain.resolution}x${this.terrain.resolution} (${this.terrain.vertexCount} sommets)`,
      `Scène : ${s.getActiveMeshes().length} meshes, ${this.inst.drawCallsCounter.current} appels de dessin, ${Math.round(s.getActiveIndices() / 3)} triangles`,
      `Joueur : x ${p.x.toFixed(1)}  y ${p.y.toFixed(1)}  z ${p.z.toFixed(1)}  |  vitesse ${this.player.speed.toFixed(1)} m/s`,
      `Appareil : ratio ${window.devicePixelRatio}  |  mémoire JS ${heap}`,
      `Erreurs : ${ErrorLog.errorCount}  |  avertissements : ${ErrorLog.warnCount}`,
    ];
    for (const entry of ErrorLog.entries.slice(-6)) {
      lines.push(`[${entry.level} t=${entry.time}s${entry.count > 1 ? ` x${entry.count}` : ""}] ${entry.msg}`);
    }
    return lines.join("\n");
  }

  private async copy(): Promise<void> {
    const text = this.report() + "\nUA: " + navigator.userAgent;
    try {
      await navigator.clipboard.writeText(text);
      this.text.textContent = "Rapport copié.\n\n" + text;
    } catch {
      this.text.textContent = "Copie impossible : sélectionnez le texte ci-dessous.\n\n" + text;
    }
  }
}

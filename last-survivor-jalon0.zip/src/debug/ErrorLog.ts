export type LogLevel = "info" | "warn" | "error";

export interface LogEntry {
  level: LogLevel;
  msg: string;
  count: number;
  time: number; // secondes depuis le chargement
}

/** Journal d'erreurs : indispensable sur iPhone, où il n'y a pas de console. */
class ErrorLogImpl {
  readonly entries: LogEntry[] = [];
  errorCount = 0;
  warnCount = 0;
  private installed = false;

  add(level: LogLevel, msg: string): void {
    const text = msg.length > 300 ? msg.slice(0, 300) + "…" : msg;
    const last = this.entries[this.entries.length - 1];
    if (last && last.level === level && last.msg === text) {
      last.count++;
    } else {
      this.entries.push({ level, msg: text, count: 1, time: Math.round(performance.now() / 1000) });
      if (this.entries.length > 40) this.entries.shift();
    }
    if (level === "error") this.errorCount++;
    if (level === "warn") this.warnCount++;
  }

  install(): void {
    if (this.installed) return;
    this.installed = true;

    window.addEventListener("error", (e) => {
      this.add("error", `${e.message} (${(e.filename || "").split("/").pop()}:${e.lineno})`);
    });
    window.addEventListener("unhandledrejection", (e) => {
      const r = e.reason;
      this.add("error", "Promesse rejetée : " + (r instanceof Error ? r.message : String(r)));
    });

    const origWarn = console.warn.bind(console);
    const origError = console.error.bind(console);
    console.warn = (...args: unknown[]) => {
      this.add("warn", args.map(String).join(" "));
      origWarn(...args);
    };
    console.error = (...args: unknown[]) => {
      this.add("error", args.map(String).join(" "));
      origError(...args);
    };
  }
}

export const ErrorLog = new ErrorLogImpl();

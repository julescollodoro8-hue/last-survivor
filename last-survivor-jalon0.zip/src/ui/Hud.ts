import type { EventBus, GameEvents } from "../core/System";
import type { QualityId, QualitySettings } from "../core/quality";
import { el } from "./dom";

export interface HudHost {
  readonly events: EventBus<GameEvents>;
  readonly quality: QualitySettings;
  setQuality(id: QualityId): void;
}

/** Interface : boutons, panneau des réglages, ouverture/fermeture des panneaux, aide de départ. */
export class Hud {
  constructor(host: HudHost) {
    const settings = el("panel-settings");
    const diag = el("panel-diag");

    el("btn-settings").addEventListener("click", () => {
      settings.hidden = !settings.hidden;
      diag.hidden = true;
    });
    el("btn-diag").addEventListener("click", () => {
      diag.hidden = !diag.hidden;
      settings.hidden = true;
    });
    document.querySelectorAll<HTMLElement>("[data-close]").forEach((b) =>
      b.addEventListener("click", () => {
        const panel = b.closest(".panel") as HTMLElement | null;
        if (panel) panel.hidden = true;
      }),
    );

    const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>("[data-q]"));
    const refresh = (): void => buttons.forEach((b) => b.classList.toggle("on", b.dataset.q === host.quality.id));
    buttons.forEach((b) => b.addEventListener("click", () => host.setQuality(b.dataset.q as QualityId)));
    host.events.on("qualityChanged", refresh);
    refresh();

    const hint = el("hint");
    const hideHint = (): void => hint.classList.add("hide");
    window.setTimeout(hideHint, 8000);
    window.addEventListener("pointerdown", hideHint, { once: true });
  }
}

/** Récupère un élément du DOM par id, ou lève une erreur claire. */
export function el<T extends HTMLElement = HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Élément #${id} introuvable dans index.html`);
  return node as T;
}

import { FreeCamera, Vector3 } from "@babylonjs/core";
import { CAMERA, WORLD } from "../core/config";
import type { System } from "../core/System";
import type { InputManager } from "../input/InputManager";
import { clamp } from "../world/noise";
import type { Terrain } from "../world/Terrain";

/** Caméra en orbite autour du joueur, empêchée de passer sous le terrain ou sous l'eau. */
export class ThirdPersonCamera implements System {
  readonly name = "camera";
  yaw = 0;
  pitch = 0.35;
  /** Position suivie (assignée par Game une fois le joueur créé). */
  focus = new Vector3();
  private readonly target = new Vector3();

  constructor(
    private readonly cam: FreeCamera,
    private readonly input: InputManager,
    private readonly terrain: Terrain,
  ) {}

  update(): void {
    const look = this.input.consumeLook();
    this.yaw += look.dx * CAMERA.lookSensX;
    this.pitch = clamp(this.pitch + look.dy * CAMERA.lookSensY, CAMERA.minPitch, CAMERA.maxPitch);

    const f = this.focus;
    this.target.set(f.x, f.y + CAMERA.height, f.z);
    const cp = Math.cos(this.pitch);
    const x = this.target.x - Math.sin(this.yaw) * cp * CAMERA.distance;
    const z = this.target.z - Math.cos(this.yaw) * cp * CAMERA.distance;
    let y = this.target.y + Math.sin(this.pitch) * CAMERA.distance;

    const floor = Math.max(this.terrain.height(x, z) + 0.5, WORLD.seaLevel + 0.4);
    if (y < floor) y = floor;

    this.cam.position.set(x, y, z);
    this.cam.setTarget(this.target);
  }
}

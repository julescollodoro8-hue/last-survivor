import { AbstractMesh, Color3, MeshBuilder, Scene, StandardMaterial, TransformNode, Vector3 } from "@babylonjs/core";
import { PLAYER } from "../core/config";
import type { System } from "../core/System";
import type { InputManager } from "../input/InputManager";
import type { Renderer } from "../render/Renderer";
import { clamp, lerp } from "../world/noise";
import type { Terrain } from "../world/Terrain";
import type { ThirdPersonCamera } from "./ThirdPersonCamera";

function lerpAngle(a: number, b: number, t: number): number {
  const twoPi = Math.PI * 2;
  const d = ((((b - a + Math.PI) % twoPi) + twoPi) % twoPi) - Math.PI;
  return a + d * t;
}

/**
 * Personnage procédural (boîtes + sphère) avec animation de marche calculée par le code.
 * Aucun modèle squelettique n'est chargé au Jalon 0.
 */
export class Player implements System {
  readonly name = "player";
  readonly position = new Vector3();
  speed = 0;

  private readonly root: TransformNode;
  private readonly body: TransformNode;
  private readonly legL: TransformNode;
  private readonly legR: TransformNode;
  private readonly armL: TransformNode;
  private readonly armR: TransformNode;
  private yaw = 0;
  private phase = 0;

  constructor(
    scene: Scene,
    private readonly terrain: Terrain,
    private readonly input: InputManager,
    private readonly camera: ThirdPersonCamera,
    renderer: Renderer,
  ) {
    const mat = (name: string, c: Color3): StandardMaterial => {
      const m = new StandardMaterial(name, scene);
      m.diffuseColor = c;
      m.specularColor = Color3.Black();
      return m;
    };
    const jacket = mat("jacket", new Color3(0.3, 0.34, 0.22));
    const pants = mat("pants", new Color3(0.2, 0.22, 0.26));
    const pack = mat("pack", new Color3(0.42, 0.36, 0.24));
    const skin = mat("skin", new Color3(0.8, 0.62, 0.5));
    const visor = mat("visor", new Color3(0.08, 0.09, 0.1));

    this.root = new TransformNode("player", scene);
    this.body = new TransformNode("playerBody", scene);
    this.body.parent = this.root;

    const box = (name: string, w: number, h: number, d: number, x: number, y: number, z: number, m: StandardMaterial, parent: TransformNode): AbstractMesh => {
      const b = MeshBuilder.CreateBox(name, { width: w, height: h, depth: d }, scene);
      b.material = m;
      b.parent = parent;
      b.position.set(x, y, z);
      b.isPickable = false;
      renderer.addCaster(b);
      return b;
    };
    const pivot = (name: string, x: number, y: number): TransformNode => {
      const p = new TransformNode(name, scene);
      p.parent = this.body;
      p.position.set(x, y, 0);
      return p;
    };

    box("torso", 0.52, 0.62, 0.3, 0, 1.15, 0, jacket, this.body);
    box("pack", 0.4, 0.5, 0.22, 0, 1.18, -0.26, pack, this.body);
    const head = MeshBuilder.CreateSphere("head", { diameter: 0.28, segments: 10 }, scene);
    head.material = skin;
    head.parent = this.body;
    head.position.set(0, 1.62, 0);
    head.isPickable = false;
    renderer.addCaster(head);
    box("visor", 0.22, 0.08, 0.06, 0, 1.64, 0.12, visor, this.body);

    this.legL = pivot("legL", -0.13, 0.8);
    this.legR = pivot("legR", 0.13, 0.8);
    box("legLm", 0.18, 0.8, 0.2, 0, -0.4, 0, pants, this.legL);
    box("legRm", 0.18, 0.8, 0.2, 0, -0.4, 0, pants, this.legR);
    this.armL = pivot("armL", -0.35, 1.42);
    this.armR = pivot("armR", 0.35, 1.42);
    box("armLm", 0.14, 0.58, 0.16, 0, -0.28, 0, jacket, this.armL);
    box("armRm", 0.14, 0.58, 0.16, 0, -0.28, 0, jacket, this.armR);

    const s = terrain.findSpawn();
    this.position.set(s.x, terrain.height(s.x, s.z), s.z);
    this.root.position.copyFrom(this.position);
  }

  private walkable(nx: number, nz: number, dist: number): boolean {
    const h = this.terrain.height(nx, nz);
    return h >= PLAYER.minGround && h - this.position.y <= PLAYER.maxSlope * dist;
  }

  /** Déplacement avec glissement le long des obstacles ; renvoie la distance réellement parcourue. */
  private tryMove(dx: number, dz: number): number {
    const p = this.position;
    const dist = Math.hypot(dx, dz);
    if (dist < 1e-6) return 0;
    if (this.walkable(p.x + dx, p.z + dz, dist)) {
      p.x += dx;
      p.z += dz;
      return dist;
    }
    if (Math.abs(dx) > 1e-6 && this.walkable(p.x + dx, p.z, Math.abs(dx))) {
      p.x += dx;
      return Math.abs(dx);
    }
    if (Math.abs(dz) > 1e-6 && this.walkable(p.x, p.z + dz, Math.abs(dz))) {
      p.z += dz;
      return Math.abs(dz);
    }
    return 0;
  }

  update(dt: number): void {
    const mx = this.input.moveX;
    const my = this.input.moveY;
    const mag = Math.min(1, Math.hypot(mx, my));
    let moved = 0;

    if (mag > 0.05) {
      const t = mag < 0.6 ? PLAYER.walkSpeed * (mag / 0.6) : lerp(PLAYER.walkSpeed, PLAYER.runSpeed, (mag - 0.6) / 0.4);
      const sin = Math.sin(this.camera.yaw);
      const cos = Math.cos(this.camera.yaw);
      let dx = sin * my + cos * mx;
      let dz = cos * my - sin * mx;
      const len = Math.hypot(dx, dz) || 1;
      dx /= len;
      dz /= len;
      moved = this.tryMove(dx * t * dt, dz * t * dt);
      this.yaw = lerpAngle(this.yaw, Math.atan2(dx, dz), 1 - Math.exp(-PLAYER.turnRate * dt));
    }

    this.position.y = this.terrain.height(this.position.x, this.position.z);
    const actual = dt > 0 ? moved / dt : 0;
    this.speed += (actual - this.speed) * (1 - Math.exp(-12 * dt));

    // Animation de marche procédurale
    const k = clamp(this.speed / PLAYER.runSpeed, 0, 1);
    this.phase += this.speed * dt * 2.2;
    const swing = Math.sin(this.phase) * 0.85 * Math.min(1, k * 1.6);
    this.legL.rotation.x = swing;
    this.legR.rotation.x = -swing;
    this.armL.rotation.x = -swing * 0.9;
    this.armR.rotation.x = swing * 0.9;
    this.body.position.y = Math.abs(Math.cos(this.phase)) * 0.05 * Math.min(1, k * 1.6);

    this.root.position.copyFrom(this.position);
    this.root.rotation.y = this.yaw;
  }
}

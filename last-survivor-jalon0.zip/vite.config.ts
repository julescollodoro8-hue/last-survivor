import { defineConfig } from "vite";

// base "./" : chemins relatifs, le jeu fonctionne sous https://<user>.github.io/<repo>/
export default defineConfig({
  base: "./",
  build: {
    target: "es2020",
    sourcemap: false,
    chunkSizeWarningLimit: 6000,
  },
  server: { host: true },
});

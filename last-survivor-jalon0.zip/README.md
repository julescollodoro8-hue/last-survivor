# LAST SURVIVOR — Jalon 0

Prototype jouable : terrain en relief, ciel, brouillard, personnage animé, caméra 3e personne,
joystick tactile, diagnostic, 3 niveaux de qualité. Babylon.js 8 + TypeScript + Vite.

## Mise en ligne (depuis iPhone)
1. Créez un dépôt GitHub et envoyez-y tous ces fichiers en gardant les chemins.
2. Dépôt > Settings > Pages > Source : **GitHub Actions**.
3. Onglet Actions > « Déployer LAST SURVIVOR » > Run workflow (ou poussez sur `main`).
4. Ouvrez l'adresse affichée dans l'étape « deploy » dans Safari.

## Architecture (src/)
- core : Game (boucle), System (interface des modules), quality, config
- render : moteur (WebGL 2 / WebGPU), scène, lumières, ciel, ombres
- world : bruit, terrain et eau
- player : personnage, caméra 3e personne
- input : joystick, caméra tactile, clavier
- ui : HUD, styles
- debug : journal d'erreurs, panneau de diagnostic

Futurs modules (ai, combat, inventory, loot, zone, vehicles, net) : un dossier + une classe `System`
ajoutée à `Game.systems`.
